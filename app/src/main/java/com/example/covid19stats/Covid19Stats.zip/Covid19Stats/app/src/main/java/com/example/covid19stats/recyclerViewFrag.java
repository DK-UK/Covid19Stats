package com.example.covid19stats;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.Toast;

import com.leo.simplearcloader.SimpleArcLoader;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


/**
 * A simple {@link Fragment} subclass.
 */
public class recyclerViewFrag extends Fragment {

    RecyclerView recyclerView;
    countryAdapter adapter;
    ArrayList<countryDetails> countryInfoArrayList;
    SimpleArcLoader simpleArcLoader;
    EditText searchbar;
    public static final String TAG = "Main";

    public recyclerViewFrag() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_recycler_view, container, false);
        setHasOptionsMenu(true);
        simpleArcLoader = view.findViewById(R.id.loader);
        searchbar = view.findViewById(R.id.searchCountry);
        recyclerView = view.findViewById(R.id.recyclerView);

        countryInfoArrayList = new ArrayList<>();

        getCountryInfo();

        adapter = new countryAdapter(getActivity(),countryInfoArrayList);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setAdapter(adapter);


        return view;
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        inflater.inflate(R.menu.searchbar,menu);

        MenuItem searchItem = menu.findItem(R.id.searchbar);
        SearchView searchView = (SearchView) searchItem.getActionView();
        searchView.setImeOptions(EditorInfo.IME_ACTION_DONE);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                return false;
            }
        });
    }

    private void getCountryInfo(){
        simpleArcLoader.start();

        Retrofit retrofit = new Retrofit.Builder()
                .addConverterFactory(GsonConverterFactory.create())
                .baseUrl("https://corona.lmao.ninja/v2/")
                .build();

        getStats getStat = retrofit.create(getStats.class);

        Call<List<countryDetails>> call = getStat.getCountryInfo();

        call.enqueue(new Callback<List<countryDetails>>() {
            @Override
            public void onResponse(Call<List<countryDetails>> call, Response<List<countryDetails>> response) {
                if (!response.isSuccessful()){
                    Toast.makeText(getActivity(),"Code : "+response.code(),Toast.LENGTH_LONG).show();
                    return;
                }

                simpleArcLoader.stop();
                simpleArcLoader.setVisibility(View.GONE);
                recyclerView.setVisibility(View.VISIBLE);

                List<countryDetails> countryInfoList = response.body();


                for (countryDetails countryInfo : countryInfoList){
                    countryInfo info = countryInfo.getCountryInfo();
                    Log.e(TAG, "flag : "+ info.getFlag()+ " Name : "+countryInfo.getCountry());
                    countryInfoArrayList.add(new countryDetails(info.getFlag(),countryInfo.getCountry()));
                }
            }

            @Override
            public void onFailure(Call<List<countryDetails>> call, Throwable t) {
                Log.e(TAG, "onFailure: "+t.getMessage());
                simpleArcLoader.stop();
                simpleArcLoader.setVisibility(View.GONE);
                recyclerView.setVisibility(View.VISIBLE);
            }
        });

    }
}
